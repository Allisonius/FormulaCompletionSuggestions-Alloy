
// A file system object in the file system
sig FSObject { parent: lone Dir }

// A directory in the file system
sig Dir extends FSObject {  contents: set FSObject }

// A file in the file system
sig File extends FSObject {  }

// A directory is the parent of its contents
fact { all d: Dir, o: d.contents | o.parent = d }

// All filesystem objects are either files or directories
fact {  File + Dir = FSObject }

// There exists a root
one sig Root extends Dir { } { no parent }

// The content path is acyclic 
assert acyclic { no d: Dir | d in  d.^contents }

// Now check it for scope of 5
check acyclic for 5

// File system has one root
assert oneRoot { one d: Dir | no d.parent }

// Now check it for a scope of 5
check oneRoot for 5

// Every fs object is in at most one directory
assert oneLocation { all o: FSObject | lone d: Dir | o in d.contents }

// Now check it for a scope of 5
check oneLocation for 5
